# paquetes internos y modulos
from .flow import grobid_request                        # grobid_interaction.py
from .flow import process_xml                           # xml_processing.py
from .flow import keyword_gen, figures_gen, gen_txt     # generations.py

from .flow.auxiliar import dw_stopwords                 # dw_sopwords.py
from .flow.auxiliar import is_active_api                # isactive.py
from .flow.auxiliar import gen_env                      # environment.py
#peticiones a api grobid
import requests, os


# Directorios
BASE_DIR = os.path.join(os.path.dirname(__file__),"..","..")
PDFS_DIR = os.path.join(BASE_DIR,"pdfs")
XMLS_DIR = os.path.join(BASE_DIR,"xmls")
FILE_DIR = os.path.join(BASE_DIR,"generated_files")

#direcciones de la api
URL_ISACTIVE = "http://localhost:8070/api/isalive"
URL_PROCESS_DOCS = "http://localhost:8070/api/processFulltextDocument"

def main():
    
    # generación del entorno    
    gen_env(PDFS_DIR, XMLS_DIR, FILE_DIR)
    
    
    # envío de peticion get a GROBID para ver si está activo
    if (is_active_api(URL_ISACTIVE)):

            #  envío de pdfs a grobid y generación de xmls
            response = grobid_request(PDFS_DIR, XMLS_DIR, URL_PROCESS_DOCS)
            if response == 0:

                # descarga de stopwords y lemmatizer en caso de no tenerlo ya
                dw_stopwords()
                
                # extraccion de nombres de xmls, abstracts, nºfiguras y links de los xmls
                xmls_abstracts_figures_links = process_xml(XMLS_DIR)
                
                if xmls_abstracts_figures_links != 1:

                    # juntar en un unico texto los abstracts y generar el keyword cloud
                    text = " ".join(xmls_abstracts_figures_links.get("abstracts"))
                    keyword_gen(text,FILE_DIR)
                    
                    # generación de una gráfica paper-nº figuras
                    papers = xmls_abstracts_figures_links.get("xmls")
                    counts = xmls_abstracts_figures_links.get("nfigures")
                        
                    figures_gen(papers,counts,FILE_DIR)
                    
                    # generación .txt con links por cada paper
                    links_per_paper = xmls_abstracts_figures_links.get("links_per_paper")
                    gen_txt(links_per_paper,FILE_DIR)
                    


# declaracion de que el main se ejecute al llamar al paquete pipegrobid                    
if __name__ == "__main__":
    main()          
