import os

def gen_env(dir_pdfs, dir_xmls, dir_genfiles):
    
    os.makedirs(dir_pdfs,  exist_ok=True)
    os.makedirs(dir_xmls,  exist_ok=True)
    os.makedirs(dir_genfiles,  exist_ok=True)

    