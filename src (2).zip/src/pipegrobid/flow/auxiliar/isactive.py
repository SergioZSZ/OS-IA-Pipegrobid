import requests


def is_active_api(url):
    try:
        response = requests.get(url, timeout=5)
        return True
    except requests.exceptions.RequestException:
            print("ERROR: No se pudo conectar a GROBID, verifique si está en ejecución.")
            return False