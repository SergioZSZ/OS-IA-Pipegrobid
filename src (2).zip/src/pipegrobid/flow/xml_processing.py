from .auxiliar.clean_text import clean_text
import os
import re

from natsort import natsorted # organiza strings de manera natural (paper1,paper2,paper3 ...)
import xml.etree.ElementTree as et #extraccion de partes de un xml como si fuese un arbol


#sin este namespace no SE encuentran los nodos del xml debido al formato TEI
NS = {"tei": "http://www.tei-c.org/ns/1.0"} 



# encapsulamiento en una lista las direcciones de los xmls del directorio dado
def list_xmls(xmls_dir):
    xmls = []
    for xml in os.listdir(xmls_dir):
        if xml.endswith(".tei.xml"): 
            path = os.path.join(xmls_dir,xml) 
            xmls.append(path)  
            print(f"    {xml}")
    return xmls



# búsqueda de links en un xml (nodos ptr y texto)
def links_research(ptrs, root):
    links = []  
    for el in ptrs:              
        target = el.get("target")
        if target and target.startswith("http"):
            links.append(target)
        
    for el in root.iter():
        if el.text:
            lista = re.findall(r"https?://[^\s\"<>()]+", el.text)
            for link in lista:
                links.append(link)
    return links




# extraccion de datos del xml 
def extract_data(xml, abstracts, figures_count, links_per_paper, text):
    
    tree = et.parse(xml)    #parseamos en arbol el xml
    root = tree.getroot()   #sacamos el nodo raiz desde el que trabajamos
        
    abstract = root.find(".//tei:abstract",NS) #buscamos desde el nodo root a cualquier profundidad abstract
    figures = root.findall(".//tei:figure",NS) #buscamos todas las figuras
    ptrs = root.findall(".//tei:ptr",NS)       #en ptr hay links(en texto mas adelante)
        
            
    if abstract is not None:
        text = " ".join(abstract.itertext()) #recorre los nodos hijos de abstract para unirlo con ""
        abstracts.append(text)
        
    figures_count.append(len(figures))  #añadimos el nº de figuras que hay
    
    # busqueda de links
    links_per_paper[xml] = links_research(ptrs, root)






'''
flujo:
    1º listado de .tei.xmls y ordenación, si no hay se termina el flujo
    2º extraccion de abstracts, figures, links 
    3º limpieza de abstracts
    4º devolver diccionario {xmls, abstracts, figures, links}
'''
def process_xml(xmls_dir):
    
    # si no hay xmls warning al usuario y terminamos la ejecucion
    xmls = list_xmls(xmls_dir)
    if not xmls:
        print(f"WARNING: Ningún tei.xml en la carpeta '{xmls_dir}', por favor, genérelos mediante GROBID.")
        return 1    

    # ordenamos de menor a mayor los xmls
    xmls = natsorted(xmls)
    
    
    # extraccion de datos del xml
    abstracts = []
    figures_count = []
    links_per_paper = {}
    text: str
    

    for i, xml in enumerate(xmls):    
        extract_data(abstracts, figures_count, links_per_paper, text)


#        '''
#        PARTE 1
#        para validacion del paper1 (A Multi-Agent LLM Framework for Realistic Patient.pdf)
#        parte: abstract correspondiente al paper, nº figuras y links
#        '''
#        if i == 0:
#            print("***************************** VALIDACION ***************************** ")
#            print(f"\npaper: {xml} \n\nabstract: {abstracts[i]}\n\nnfigures: {figures_count[i]}\n\nlinks: {links_per_paper[xml]}")
#            print("\n\n\n")
#        '''
#        FIN PARTE 1
#        '''
        
        
    # limpieza del abstract y lemmatization

    cleaned_abstracts = []
    for i, abstract in enumerate(abstracts):
        cleaned_abstracts.append(clean_text(abstract))
        
        
#        '''
#        PARTE 2
#        para validacion de limpieza del abstract, lematización etc
#        '''
#        if i == 0:
#            print(f"\ncleaned abstract: {cleaned_abstracts[i]}")
#            print("\n\n\n")
#            print("********************************************************** ")
#        '''
#        FIN PARTE 1
#        '''
        

    ## hacemos return de xmls y nfigures para la visualización de figuras y abstrats para el wordcloud
    return {
            "xmls": xmls,
            "abstracts":cleaned_abstracts,
            "nfigures":figures_count,
            "links_per_paper": links_per_paper
    }

        

        

        
        

